import type { SVGProps } from "react";
const SvgBlackMan1M = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" {...props}>
    <defs>
      <mask id="Black-Man1-m_svg__b" maskUnits="userSpaceOnUse">
        <rect
          width={300.059}
          height={400.778}
          y={652.284}
          ry={40}
          style={{
            opacity: 1,
            fill: "#ff3737",
            fillOpacity: 1,
            fillRule: "nonzero",
            stroke: "none",
            strokeWidth: 10,
            strokeLinecap: "butt",
            strokeLinejoin: "round",
            strokeMiterlimit: 4,
            strokeDasharray: "none",
            strokeDashoffset: 0,
            strokeOpacity: 1,
          }}
        />
      </mask>
      <mask id="Black-Man1-m_svg__c" maskUnits="userSpaceOnUse">
        <rect
          width={300.059}
          height={400.778}
          x={-451.938}
          y={-1325.603}
          ry={40}
          style={{
            opacity: 1,
            fill: "#ff3737",
            fillOpacity: 1,
            fillRule: "nonzero",
            stroke: "none",
            strokeWidth: 10,
            strokeLinecap: "butt",
            strokeLinejoin: "round",
            strokeMiterlimit: 4,
            strokeDasharray: "none",
            strokeDashoffset: 0,
            strokeOpacity: 1,
          }}
          transform="scale(-1)"
        />
      </mask>
      <filter
        id="Black-Man1-m_svg__a"
        width={1.05}
        height={1.109}
        x={-0.025}
        y={-0.054}
      >
        <feGaussianBlur result="blur" stdDeviation="2.51 2.51" />
      </filter>
    </defs>
    <g transform="translate(0 -652.362)">
      <rect
        width={300.059}
        height={400.778}
        y={652.284}
        ry={40}
        style={{
          opacity: 1,
          fill: "#1e1e1e",
          fillOpacity: 1,
          fillRule: "nonzero",
          stroke: "none",
          strokeWidth: 10,
          strokeLinecap: "butt",
          strokeLinejoin: "round",
          strokeMiterlimit: 4,
          strokeDasharray: "none",
          strokeDashoffset: 0,
          strokeOpacity: 1,
        }}
      />
      <path
        d="M-4.769 775.071c-4.881-33.076-12.077-100.834 3.49-123.007 20.277-26.12 234.78-20.433 264.593 1.846 12.9 8.739-192.964 9.211-216.215 37.835C24.391 719.112.651 818.187-4.769 775.07"
        mask="url(#Black-Man1-m_svg__b)"
        style={{
          fill: "#fff",
          fillOpacity: 0.15686275,
          fillRule: "evenodd",
          stroke: "none",
          strokeWidth: 1,
          strokeLinecap: "butt",
          strokeLinejoin: "miter",
          strokeOpacity: 1,
          filter: "url(#Black-Man1-m_svg__a)",
        }}
      />
      <path
        d="M151.736 1025.018c-3.327-9.314-10.249-68.454 5.318-90.627 20.277-26.12 219.436-16.458 231.555-9.932 11.074 5.317-178.604.06-204.851 34.867-21.594 30-26.501 82.178-32.022 65.692"
        mask="url(#Black-Man1-m_svg__c)"
        style={{
          fill: "#000",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "none",
          strokeWidth: 1,
          strokeLinecap: "butt",
          strokeLinejoin: "miter",
          strokeOpacity: 1,
          filter: "url(#Black-Man1-m_svg__a)",
        }}
        transform="rotate(180 225.969 988.943)"
      />
    </g>
    <path
      d="M52.894 722.322c-17.507-.113-9.053 18.9-.906 19.472 56.421 12.318 92.34-11.637 131.425-9.525 20.679 2.05 53.824 11.04 61.514 15.63 1.638.978 3.978.741 4.995.2 8.34-4.393 7.713-25.104 4.358-36.852-.932-3.487-8.67-7.711-15.057.178-2.094 2.11-10.85.64-12.705-.624-8.379-5.714-31.444-11.187-43.558-8.083-46.229 9.758-82.747 26.55-130.066 19.604"
      style={{
        fill: "#fff",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(0 -652.362)"
    />
    <path
      d="M-973.9 230.335c101.51 10.776 95.086-15.763 180.061-18.577 18.885-2.746 17.635-17.46-.449-16.017-90.368 2.243-58.78 34.94-177.693 16.091-28.997-5.176-24.264 14.568-1.919 18.503"
      style={{
        fill: "#f0a023",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(1034.343 -3.476)"
    />
    <path
      d="M-882.636 187.136c1.312-3.924-7.997-10.181-13.22-3.472-4.83 7.479-6.263 12.155-10.86 17.42-1.958 2.393-2.24 7.725-.216 9.267 7.568 6.199 6.724 4.784 11.5 14.738l20.53-1.762c-6.52-8.589-7.597-7.834-10.131-16.424-1.165-9.327-.808-10.176 2.397-19.767M-856.843 149.174c-2.072-2.165-3.31-2.932-6.213 0l-15.391 15.54c-1.348 1.501-1.372 3.706-.264 4.97l9.17 8.834c4.353 4.252 5.464 7.314 2.9 12.336-3.42 9.616-5.987 19.367-6.097 24.708l21.18-3.487c-3.959-9.818-3.87-12.358 2.866-21.647 5.559-6.327 10.933-7.774 5.995-16.417zM-834.44 229.53c-2.379 0-5.115.351-7.986.675-25.98 4.24-44.632 13.662-87.783 12.14-5.841.03-10.797 3.109-10.592 7.59.416 9.893 7.7 62.177 8.305 66.89.853 6.417 9.79 6.987 10.967 1.34.215-1.033.221-3.957.098-7.995.547-1.144 1.397-2.02 2.308-2.184l56.983-5.092c.58.007 1.014.545 1.32 1.33-.442 20.094-.684 39.742-.254 46.624.124 1.52.051 3.12 1.57 4.486 3.627 3.034 24.108 1.363 29.408-1.947 1.469-1.078 2-1.583 2.198-3.83-2.961-33.992-.668-77.218 1.605-110.873.597-7.453-2.911-9.155-8.146-9.155m-26.98 16.763c5.652-1.39 2.022 15.828.088 15.877l-58.828 4.611c-5.127-1.024-4.88-13.066-1.422-13.228 26.639-.896 35.744-3.181 60.162-7.26m-.129 29.152c1.706-.13 2.018 12.385-.38 12.586l-57.32 4.797c-4.102-1.15-4.353-11.962-.78-12.492z"
      style={{
        fill: "#f0a023",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(1034.343 -3.476)"
    />
    <path
      d="m-881.542 246.32-19.233.635-5.291 90.56c-.751 10.291 4.492 20.61 11.24 20.762l18.743-6.546z"
      style={{
        fill: "#f0a023",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(1034.343 -3.476)"
    />
    <path
      d="m-942.636 354.94.846 8.028c54.246 18.284 41.637-8.576 96.894-15.151l-.634-4.928c-42.242-2.988-64.353 13.179-97.106 12.051"
      style={{
        fill: "#f0a023",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(1034.343 -3.476)"
    />
    <path
      d="M-947.816 295.507c-4.79-14.35-18.047-11.53-15.57.885 13.898 43.448 17.943 67.498 19.8 70.859 10.792 18.228 18.402 13.453 19.078-2.434.112-4.85-14.234-43.495-23.308-69.31"
      style={{
        fill: "#f0a023",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(1034.343 -3.476)"
    />
    <path
      d="M-990.503 324.512c-8.36-1.304-7.6 9.084-3.317 11.288 59.848 26.468 123.839-8.865 177.967-5.69 2.058.368 5.312 1.563 8.294 3.201 9.557 5.048 3.734 19.51-.976 22.479-21.536 9.845-16.514.091-40.673 11.25-2.278 1.46-8.257 2.596-10.482 1.685-8.943-2.978-16.302-8.103-22.15-12.665l-11.189 5.646c6.906 8.601 17.1 12.672 25.541 16.372 6.747 3.213 14.126 2.854 19.03 3.005 25.107.345 48.588-9.297 60.402-10.755 3.458-.53 7.483-6.526 9.05-9.31 9.692-15.872 5.689-18.57-1.085-35.189-3.85-6.232-14.98-8.011-20.828-8.804-60.717-2.575-138.254 18.811-189.584 7.487"
      style={{
        fill: "#f0a023",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="translate(1034.343 -3.476)"
    />
  </svg>
);
export default SvgBlackMan1M;
