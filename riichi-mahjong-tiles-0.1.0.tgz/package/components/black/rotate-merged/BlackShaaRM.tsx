import type { SVGProps } from "react";
const SvgBlackShaaRM = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" {...props}>
    <defs>
      <mask id="Black-Shaa-r-m_svg__b" maskUnits="userSpaceOnUse">
        <rect
          width={300.059}
          height={400.778}
          y={652.284}
          ry={40}
          style={{
            opacity: 1,
            fill: "#ff3737",
            fillOpacity: 1,
            fillRule: "nonzero",
            stroke: "none",
            strokeWidth: 10,
            strokeLinecap: "butt",
            strokeLinejoin: "round",
            strokeMiterlimit: 4,
            strokeDasharray: "none",
            strokeDashoffset: 0,
            strokeOpacity: 1,
          }}
        />
      </mask>
      <mask id="Black-Shaa-r-m_svg__c" maskUnits="userSpaceOnUse">
        <rect
          width={300.059}
          height={400.778}
          x={-451.938}
          y={-1325.603}
          ry={40}
          style={{
            opacity: 1,
            fill: "#ff3737",
            fillOpacity: 1,
            fillRule: "nonzero",
            stroke: "none",
            strokeWidth: 10,
            strokeLinecap: "butt",
            strokeLinejoin: "round",
            strokeMiterlimit: 4,
            strokeDasharray: "none",
            strokeDashoffset: 0,
            strokeOpacity: 1,
          }}
          transform="scale(-1)"
        />
      </mask>
      <filter
        id="Black-Shaa-r-m_svg__a"
        width={1.05}
        height={1.109}
        x={-0.025}
        y={-0.054}
      >
        <feGaussianBlur result="blur" stdDeviation="2.51 2.51" />
      </filter>
    </defs>
    <g transform="rotate(90 526.181 526.181)">
      <rect
        width={300.059}
        height={400.778}
        y={652.284}
        ry={40}
        style={{
          opacity: 1,
          fill: "#1e1e1e",
          fillOpacity: 1,
          fillRule: "nonzero",
          stroke: "none",
          strokeWidth: 10,
          strokeLinecap: "butt",
          strokeLinejoin: "round",
          strokeMiterlimit: 4,
          strokeDasharray: "none",
          strokeDashoffset: 0,
          strokeOpacity: 1,
        }}
      />
      <path
        d="M-4.769 775.071c-4.881-33.076-12.077-100.834 3.49-123.007 20.277-26.12 234.78-20.433 264.593 1.846 12.9 8.739-192.964 9.211-216.215 37.835C24.391 719.112.651 818.187-4.769 775.07"
        mask="url(#Black-Shaa-r-m_svg__b)"
        style={{
          fill: "#fff",
          fillOpacity: 0.15686275,
          fillRule: "evenodd",
          stroke: "none",
          strokeWidth: 1,
          strokeLinecap: "butt",
          strokeLinejoin: "miter",
          strokeOpacity: 1,
          filter: "url(#Black-Shaa-r-m_svg__a)",
        }}
      />
      <path
        d="M151.736 1025.018c-3.327-9.314-10.249-68.454 5.318-90.627 20.277-26.12 219.436-16.458 231.555-9.932 11.074 5.317-178.604.06-204.851 34.867-21.594 30-26.501 82.178-32.022 65.692"
        mask="url(#Black-Shaa-r-m_svg__c)"
        style={{
          fill: "#000",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "none",
          strokeWidth: 1,
          strokeLinecap: "butt",
          strokeLinejoin: "miter",
          strokeOpacity: 1,
          filter: "url(#Black-Shaa-r-m_svg__a)",
        }}
        transform="rotate(180 225.969 988.943)"
      />
    </g>
    <path
      d="M18.303 756.6c-9.586 1.253-21.044-11.13-7.344-14.66 43.69-8.445 191.763-31.914 208.715-38.97 14.882-4.476 48.78 19.646 69.772 30.824 13.035 7.626 7.097 16.274-2.938 20.175-8.125 2.447-55.98 6.847-81.613 3.759-4.89-.5-3.035-12.309-13.956-14.002-50.104-9.31-121.715 6.609-172.636 12.874"
      style={{
        fill: "#fff",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="matrix(0 .85009 -.93539 0 995.253 19.53)"
    />
    <path
      d="M202.3 755.155c-1.275 3.789-1.924 9.06-4.622 10.318-5.18 1.776-10.933.562-13.808 5-4.19 6.732-29.81 25.813-47.58 39.893-5.04 3.992-13.56 1.057-14.11-6.386l-.068 27.464 12.62-.624c10.987-8.589 41.279-37.359 54.83-37.696 10.772-.855 23.242-4.166 26.21-11.339 2.5-6.407-4.914-10.93-4.229-14.504 1.07-4.177 9.936-8.481 12.91-8.514 5.076-.056-20.883-7.645-22.152-3.612"
      style={{
        fill: "#fff",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="matrix(0 .85009 -.93539 0 995.253 19.53)"
    />
    <path
      d="M44.513 845.652c52.142-12.4 175.205-50.85 193.237-43.657 22.34 10.87 63.544 36.445 64.115 47.242.226 10.504.098 11.397-8.759 19.874-13.17 12.93-55.353 77.186-61.499 101.906-1.422 6.271-.443 18.401-5.167 23.428-6.613 7.365-88.046-1.13-141.056-3.23-17.92-.6-26.244-18.982.533-19.54 34.106-.614 92.368-2.022 99.276-10.493 6.239-7.953 49.264-97.451 49.364-107.09.106-6.046-10.735-20.21-17.193-24.295-7.881-5.57-118.387 28.03-167.578 35.02z"
      style={{
        fill: "#fff",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="matrix(0 .85009 -.93539 0 995.253 19.53)"
    />
    <path
      d="M22.79 858.993c13.914 26.906 43.91 76.585 55.89 124.515l32.084-2.126c-7.936-36.068-27.317-97.355-46.123-127.42-33.87-53.702-70.167-46.594-41.851 5.031M121.164 783.923c-3.212-15.545-15.495-12.916-13.587 3.497l18.464 193.393 14.143-.7zM189.657 785.116h-13.324l-25.127 191.878h12.92z"
      style={{
        fill: "#fff",
        fillOpacity: 1,
        fillRule: "evenodd",
        stroke: "none",
        strokeWidth: 1,
        strokeLinecap: "butt",
        strokeLinejoin: "miter",
        strokeOpacity: 1,
      }}
      transform="matrix(0 .85009 -.93539 0 995.253 19.53)"
    />
  </svg>
);
export default SvgBlackShaaRM;
