import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['index.ts'],
  dts: {
    resolve: true,
    compilerOptions: {
      declaration: true,
    }
  },
  format: ['esm'],
  outDir: 'dist',
  clean: true,
  external: ['react', 'react-dom'],
  sourcemap: true,
});
